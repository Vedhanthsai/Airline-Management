## Links
Website Link : https://dev-rev-flight-booking-frontend.vercel.app/

Api Documentation Link : https://docs.google.com/document/d/16_NfIK5zaLR8pGX84tTf7zJJFJEnjBWR7Q4Yr8Vfsgg/edit?usp=drivesdk

## Admin Login Details
email : tes1t@gmail.com

password : 123456789

## User Login Details
email : janeprakeerth@gmail.com

password : 123456789


# Flight Search Details
 Source City : Delhi
 
 Destination City : Leh

 Travel Date : 22-07-2023

